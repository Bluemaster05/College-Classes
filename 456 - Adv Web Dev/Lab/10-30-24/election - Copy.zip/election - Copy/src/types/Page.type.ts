export type Page = "candidates" | "results" | "votes"
