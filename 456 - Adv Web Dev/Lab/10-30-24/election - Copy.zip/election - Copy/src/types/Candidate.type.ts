export type Candidate = {
    candidateId: number
    name: string
    party: string
    description: string
    pictureUrl: string
}
