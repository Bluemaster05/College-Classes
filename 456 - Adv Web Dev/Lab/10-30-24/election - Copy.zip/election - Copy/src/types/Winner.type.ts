export type Winner = {
    candidateId: number
    receivedVotes: number
    totalVotes: number
}
