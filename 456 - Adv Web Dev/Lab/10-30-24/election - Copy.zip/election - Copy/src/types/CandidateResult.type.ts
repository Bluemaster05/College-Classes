export type CandidateResult = {
    candidateId: number
    votes: number
}
