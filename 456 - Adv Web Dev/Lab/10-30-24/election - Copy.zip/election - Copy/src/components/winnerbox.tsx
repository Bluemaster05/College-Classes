export function WinnerBox(){
    return <div
    style={{
        backgroundColor: 'red',
        // height: '20px',
        // width: '80px',
        padding: '6px',
        border: '2px solid white',
        borderRadius: '10px',
        position: 'absolute',
        top: '-20px',
        left: '-30px'
        }}>
        Winner
    </div>
}