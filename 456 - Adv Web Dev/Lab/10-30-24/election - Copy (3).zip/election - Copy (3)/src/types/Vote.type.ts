export type Vote = {
    voterId: number
    voterName: string
    candidateId: number
    voteDate: string
}
