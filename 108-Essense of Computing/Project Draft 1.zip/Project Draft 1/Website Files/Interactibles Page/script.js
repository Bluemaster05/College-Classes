const rect = document.querySelector("rect")
const rectSVG = document.getElementById("rectSVG")
const circle = document.querySelector("circle")
const circleSVG = document.getElementById("circleSVG")
const line = document.querySelector('line')
const lineSVG = document.getElementById('lineSVG')


// RECTANGLE CODE
function changeRectSVGWidth() {
    let newSVGWidth = document.getElementById("rectSVGW").value
    rectSVG.setAttribute('width', newSVGWidth)
}
document.getElementById("rectSVGW").addEventListener('change', changeRectSVGWidth)

function changeRectSVGHeight() {
    let newSVGHeight = document.getElementById("rectSVGW").value
    rectSVG.setAttribute('height', newSVGHeight)
}
document.getElementById("rectSVGH").addEventListener('change', changeRectSVGHeight)

function changeRectWidth() {
    let newWidth = document.getElementById("rectWidth").value
    rect.setAttribute('width', newWidth)
}
document.getElementById("rectWidth").addEventListener('change', changeRectWidth)

function changeRectHeight() {
    let newHeight = document.getElementById("rectHeight").value
    rect.setAttribute('height', newHeight)
}
document.getElementById("rectHeight").addEventListener('change', changeRectHeight)

function changeRectx() {
    let newX = document.getElementById("rectX").value
    rect.setAttribute('x', newX)
}
document.getElementById("rectX").addEventListener('change', changeRectx)

function changeRecty() {
    let newY = document.getElementById("rectY").value
    rect.setAttribute('y', newY)
}
document.getElementById("rectY").addEventListener('change', changeRecty)

function changeRectRx() {
    let newRx = document.getElementById("rectRX").value
    rect.setAttribute('rx', newRx)
}
document.getElementById("rectRX").addEventListener('change', changeRectRx)

function changeRectFill() {
    let newRectFill = document.getElementById("rectFill").value
    rect.setAttribute('fill', newRectFill)
}
document.getElementById("rectFill").addEventListener('change', changeRectFill)

function changeRectStrokeWidth() {
    let newRectStrokeW = document.getElementById("rectStrokeWidth").value
    rect.setAttribute('stroke-width', newRectStrokeW)
}
document.getElementById("rectStrokeWidth").addEventListener('change', changeRectStrokeWidth)

function changeRectStrokeColor() {
    let newRectStrokeColor = document.getElementById("rectStrokeColor").value
    rect.setAttribute('stroke', newRectStrokeColor)
}
document.getElementById("rectStrokeColor").addEventListener('change', changeRectStrokeColor)

//CIRCLE CODE

function changeCircleSVGW() {
    debugger
    let newCircleSVGW = document.getElementById("circleSVGW").value
    console.log(newCircleSVGW)
    circleSVG.setAttribute('width', newCircleSVGW)
}
document.getElementById("circleSVGW").addEventListener('change', changeCircleSVGW)

function changeCircleSVGH() {
    let newCircleSVGH = document.getElementById("circleSVGH").value
    circleSVG.setAttribute('height', newCircleSVGH)
}

function changeCircleRx() {
    let newRx = document.getElementById("CircleR").value
    rect.setAttribute('rx', newRx)
}
// document.getElementById("CircleRX").addEventListener('change', changeRectRx)

function changeCirclex() {
    let newX = document.getElementById("Circlex").value
    rect.setAttribute('x', newX)
}
// document.getElementById("Circlex").addEventListener('change', changeRectx)

function changeCircley() {
    let newY = document.getElementById("CircleY").value
    rect.setAttribute('y', newY)
}